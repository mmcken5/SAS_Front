import { storageFor } from 'ember-local-storage/helpers/storage';

export { storageFor };