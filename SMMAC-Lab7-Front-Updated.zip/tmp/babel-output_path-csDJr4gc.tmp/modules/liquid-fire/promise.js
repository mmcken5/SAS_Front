// Ember is already polyfilling Promise as needed, so just use that.
import Ember from "ember";
export default Ember.RSVP.Promise;