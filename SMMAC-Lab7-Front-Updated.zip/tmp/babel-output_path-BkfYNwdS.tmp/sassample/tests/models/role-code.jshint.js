define('sassample/tests/models/role-code.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - models/role-code.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/role-code.js should pass jshint.');
  });
});