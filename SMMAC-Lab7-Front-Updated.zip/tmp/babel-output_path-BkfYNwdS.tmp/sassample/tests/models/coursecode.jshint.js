define('sassample/tests/models/coursecode.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - models/coursecode.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/coursecode.js should pass jshint.');
  });
});