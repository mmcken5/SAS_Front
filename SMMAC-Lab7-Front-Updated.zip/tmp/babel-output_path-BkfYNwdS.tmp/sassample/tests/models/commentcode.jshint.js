define('sassample/tests/models/commentcode.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - models/commentcode.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/commentcode.js should pass jshint.');
  });
});