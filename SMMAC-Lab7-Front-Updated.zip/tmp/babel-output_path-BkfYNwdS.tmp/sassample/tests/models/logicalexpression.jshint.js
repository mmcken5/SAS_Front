define('sassample/tests/models/logicalexpression.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - models/logicalexpression.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/logicalexpression.js should pass jshint.');
  });
});