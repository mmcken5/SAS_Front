define('sassample/tests/models/user-role.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - models/user-role.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/user-role.js should pass jshint.');
  });
});