define('sassample/tests/models/faculty.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - models/faculty.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/faculty.js should pass jshint.');
  });
});