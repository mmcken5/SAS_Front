define('sassample/tests/models/admissionrule.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - models/admissionrule.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/admissionrule.js should pass jshint.');
  });
});