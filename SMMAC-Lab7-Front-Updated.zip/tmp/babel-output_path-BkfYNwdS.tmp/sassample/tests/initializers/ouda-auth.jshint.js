define('sassample/tests/initializers/ouda-auth.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - initializers/ouda-auth.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'initializers/ouda-auth.js should pass jshint.');
  });
});