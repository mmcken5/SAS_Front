define('sassample/tests/routes/load.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - routes/load.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'routes/load.js should pass jshint.');
  });
});