define('sassample/tests/routes/results.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - routes/results.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'routes/results.js should pass jshint.');
  });
});