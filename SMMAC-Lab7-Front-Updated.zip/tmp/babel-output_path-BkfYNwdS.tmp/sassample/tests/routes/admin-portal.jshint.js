define('sassample/tests/routes/admin-portal.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - routes/admin-portal.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'routes/admin-portal.js should pass jshint.');
  });
});