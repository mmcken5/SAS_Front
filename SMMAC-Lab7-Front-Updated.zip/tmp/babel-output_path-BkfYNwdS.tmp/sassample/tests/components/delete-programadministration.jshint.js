define('sassample/tests/components/delete-programadministration.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - components/delete-programadministration.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/delete-programadministration.js should pass jshint.');
  });
});