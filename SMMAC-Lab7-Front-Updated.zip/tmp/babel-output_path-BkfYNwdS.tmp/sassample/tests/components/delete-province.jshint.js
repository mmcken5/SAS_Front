define('sassample/tests/components/delete-province.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - components/delete-province.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/delete-province.js should pass jshint.');
  });
});