define('sassample/tests/components/assign-role.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - components/assign-role.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/assign-role.js should pass jshint.');
  });
});