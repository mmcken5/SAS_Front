define('sassample/tests/components/manage-residency.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - components/manage-residency.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/manage-residency.js should pass jshint.');
  });
});