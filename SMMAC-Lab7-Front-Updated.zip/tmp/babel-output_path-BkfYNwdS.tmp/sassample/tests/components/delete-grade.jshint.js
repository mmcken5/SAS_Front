define('sassample/tests/components/delete-grade.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - components/delete-grade.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/delete-grade.js should pass jshint.');
  });
});