define('sassample/tests/components/log-out.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - components/log-out.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/log-out.js should pass jshint.');
  });
});