define('sassample/tests/components/manage-academicload.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - components/manage-academicload.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/manage-academicload.js should pass jshint.');
  });
});