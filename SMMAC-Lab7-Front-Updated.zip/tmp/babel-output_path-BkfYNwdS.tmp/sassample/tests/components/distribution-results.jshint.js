define('sassample/tests/components/distribution-results.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - components/distribution-results.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(false, 'components/distribution-results.js should pass jshint.\ncomponents/distribution-results.js: line 45, col 45, Expected \'{\' and instead saw \'out\'.\ncomponents/distribution-results.js: line 46, col 18, Expected \'{\' and instead saw \'out\'.\ncomponents/distribution-results.js: line 40, col 17, \'self\' is defined but never used.\ncomponents/distribution-results.js: line 45, col 16, \'out\' is not defined.\ncomponents/distribution-results.js: line 45, col 45, \'out\' is not defined.\ncomponents/distribution-results.js: line 46, col 18, \'out\' is not defined.\n\n6 errors');
  });
});