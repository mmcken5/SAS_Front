define('sassample/tests/components/delete-role.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - components/delete-role.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/delete-role.js should pass jshint.');
  });
});