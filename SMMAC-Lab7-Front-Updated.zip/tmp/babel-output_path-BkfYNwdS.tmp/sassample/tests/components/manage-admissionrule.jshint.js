define('sassample/tests/components/manage-admissionrule.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - components/manage-admissionrule.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/manage-admissionrule.js should pass jshint.');
  });
});