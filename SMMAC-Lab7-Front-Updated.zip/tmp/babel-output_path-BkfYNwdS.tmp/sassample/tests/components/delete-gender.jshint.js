define('sassample/tests/components/delete-gender.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - components/delete-gender.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/delete-gender.js should pass jshint.');
  });
});