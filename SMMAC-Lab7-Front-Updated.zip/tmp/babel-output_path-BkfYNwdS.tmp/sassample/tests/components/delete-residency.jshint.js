define('sassample/tests/components/delete-residency.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - components/delete-residency.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/delete-residency.js should pass jshint.');
  });
});