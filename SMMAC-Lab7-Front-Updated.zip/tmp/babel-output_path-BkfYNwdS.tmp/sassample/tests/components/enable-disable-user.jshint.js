define('sassample/tests/components/enable-disable-user.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - components/enable-disable-user.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/enable-disable-user.js should pass jshint.');
  });
});