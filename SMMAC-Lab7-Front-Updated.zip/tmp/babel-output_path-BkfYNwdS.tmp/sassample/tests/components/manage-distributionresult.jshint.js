define('sassample/tests/components/manage-distributionresult.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - components/manage-distributionresult.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/manage-distributionresult.js should pass jshint.');
  });
});