define('sassample/tests/components/authenticate-user.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - components/authenticate-user.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(false, 'components/authenticate-user.js should pass jshint.\ncomponents/authenticate-user.js: line 28, col 84, \'userRole\' is defined but never used.\n\n1 error');
  });
});