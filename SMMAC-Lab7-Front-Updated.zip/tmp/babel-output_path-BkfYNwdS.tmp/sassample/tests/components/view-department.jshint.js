define('sassample/tests/components/view-department.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - components/view-department.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(false, 'components/view-department.js should pass jshint.\ncomponents/view-department.js: line 19, col 51, Missing semicolon.\ncomponents/view-department.js: line 20, col 7, Missing semicolon.\ncomponents/view-department.js: line 23, col 42, Missing semicolon.\ncomponents/view-department.js: line 18, col 9, \'selectedFaculty\' is defined but never used.\n\n4 errors');
  });
});