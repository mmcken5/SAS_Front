define('sassample/tests/components/view-grades.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - components/view-grades.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(false, 'components/view-grades.js should pass jshint.\ncomponents/view-grades.js: line 16, col 17, \'selectedStudent\' is defined but never used.\ncomponents/view-grades.js: line 30, col 45, Missing semicolon.\ncomponents/view-grades.js: line 33, col 17, \'selectedGrade\' is defined but never used.\n\n3 errors');
  });
});