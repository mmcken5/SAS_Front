define('sassample/tests/components/delete-academicload.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - components/delete-academicload.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/delete-academicload.js should pass jshint.');
  });
});