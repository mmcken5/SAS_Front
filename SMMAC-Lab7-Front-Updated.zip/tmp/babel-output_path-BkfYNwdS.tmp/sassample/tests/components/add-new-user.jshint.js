define('sassample/tests/components/add-new-user.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - components/add-new-user.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/add-new-user.js should pass jshint.');
  });
});