define('sassample/tests/components/manage-academicprogramcode.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - components/manage-academicprogramcode.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/manage-academicprogramcode.js should pass jshint.');
  });
});