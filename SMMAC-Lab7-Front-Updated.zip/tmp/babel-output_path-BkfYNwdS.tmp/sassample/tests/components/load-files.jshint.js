define('sassample/tests/components/load-files.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - components/load-files.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/load-files.js should pass jshint.');
  });
});