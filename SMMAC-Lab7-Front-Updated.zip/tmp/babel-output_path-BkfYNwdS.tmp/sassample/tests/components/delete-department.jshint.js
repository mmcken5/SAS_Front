define('sassample/tests/components/delete-department.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - components/delete-department.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/delete-department.js should pass jshint.');
  });
});