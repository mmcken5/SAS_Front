define('sassample/tests/components/view-logicalexpression.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - components/view-logicalexpression.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(false, 'components/view-logicalexpression.js should pass jshint.\ncomponents/view-logicalexpression.js: line 21, col 56, Missing semicolon.\n\n1 error');
  });
});