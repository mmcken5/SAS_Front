define('sassample/tests/components/add-new-student.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - components/add-new-student.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/add-new-student.js should pass jshint.');
  });
});