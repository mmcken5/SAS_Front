define('sassample/tests/components/image-input.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - components/image-input.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(false, 'components/image-input.js should pass jshint.\ncomponents/image-input.js: line 12, col 29, Missing semicolon.\n\n1 error');
  });
});