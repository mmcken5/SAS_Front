define('sassample/tests/components/manage-city.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - components/manage-city.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/manage-city.js should pass jshint.');
  });
});