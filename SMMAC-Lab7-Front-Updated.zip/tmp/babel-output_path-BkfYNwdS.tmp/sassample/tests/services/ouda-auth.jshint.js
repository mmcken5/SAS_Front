define('sassample/tests/services/ouda-auth.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - services/ouda-auth.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'services/ouda-auth.js should pass jshint.');
  });
});