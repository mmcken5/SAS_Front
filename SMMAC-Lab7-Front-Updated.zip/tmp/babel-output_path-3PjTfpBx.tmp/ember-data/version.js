define("ember-data/version", ["exports"], function (exports) {
  "use strict";

  exports["default"] = "2.3.0";
});