define('ember-local-storage/index', ['exports', 'ember-local-storage/helpers/storage'], function (exports, _emberLocalStorageHelpersStorage) {
  'use strict';

  exports.storageFor = _emberLocalStorageHelpersStorage.storageFor;
});